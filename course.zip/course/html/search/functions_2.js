var searchData=
[
  ['generate_5frandom_5fstudent_23',['generate_random_student',['../student_8c.html#a4aa2c655fdf24df90c3e85b18f605b9a',1,'student.c']]]
];
