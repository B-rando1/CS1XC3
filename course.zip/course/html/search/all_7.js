var searchData=
[
  ['student_12',['Student',['../student_8c.html#ac91ec92866bb82e1ee36c75280929c43',1,'student.c']]],
  ['student_2ec_13',['student.c',['../student_8c.html',1,'']]]
];
