var searchData=
[
  ['student_29',['Student',['../student_8c.html#ac91ec92866bb82e1ee36c75280929c43',1,'student.c']]]
];
