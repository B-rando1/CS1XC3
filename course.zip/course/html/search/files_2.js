var searchData=
[
  ['student_2ec_19',['student.c',['../student_8c.html',1,'']]]
];
