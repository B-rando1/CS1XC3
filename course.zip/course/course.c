/**
 * @file course.c
 * @author Sharmin Ahmed
 * @brief A library for creating courses with students
 * @version 0.1
 * @date 2022-04-04
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * @brief Adds a student to a course
 * 
 * @param course The course you would like to add the student to
 * @param student The student you would like to add
 */
void enroll_student(Course *course, Student *student)
{
  // Increment the total number of students
  course->total_students++;
  // If this is the first student, create new memory to hold it, otherwise, expand the existing memory
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  // Add the student to the course's list
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief Prints the course information, then each student and their information.
 * 
 * @param course The course you would like to print
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  
  // Loop through each student and print their information.
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief Finds the top student
 * 
 * @param course The course you are checking
 * @return Student* A pointer to the top student
 */
Student* top_student(Course* course)
{
  // If the course has no students, return null
  if (course->total_students == 0) return NULL;
  
  // Loop through every student to find the one with the highest average
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief Finds all students who are passing and return an array of them
 * 
 * @param course The course you are checking
 * @param total_passing The pointer to an integer to store the number of students who are passing
 * @return Student* An array of students who are passing
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  // Loop through each student to find out how many are passing
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  // Allocate an array to store the passing students
  passing = calloc(count, sizeof(Student));

  // Loop through the students and add those who are passing to the array
  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  // Set the value of total_passing to count
  *total_passing = count;

  return passing;
}