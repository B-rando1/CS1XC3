/**
 * @file student.c
 * @author Sharmin Ahmed
 * @brief A library for working with students in the courses library
 * @version 0.1
 * @date 2022-04-04
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
 * @brief Adds a grade to a student's grades
 * 
 * @param student The student you would like to give a new grade
 * @param grade The value of the grade you would like to give the student
 */
void add_grade(Student* student, double grade)
{
  // Increment the number of grades the student has, and either allocate or realloate memory in their array to hold the new grade.
  student->num_grades++;
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  student->grades[student->num_grades - 1] = grade;
}

/**
 * @brief Finds the average grade of a student
 * 
 * @param student The student to find the average of
 * @return double Average grade
 */
double average(Student* student)
{
  if (student->num_grades == 0) return 0;

  double total = 0;
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  return total / ((double) student->num_grades);
}

/**
 * @brief Prints a student's Name, ID, Grades, and Average
 * 
 * @param student The student to print
 */
void print_student(Student* student)
{
  // Print various information in a set order
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/**
 * @brief Generates a random student by randomly selecting from an array of first names and last names, and creating a random ID and array of grades.
 * 
 * @param grades The number of random grades to generate
 * @return Student* A pointer to the new random student
 */
Student* generate_random_student(int grades)
{
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  Student *new_student = calloc(1, sizeof(Student));

  // Randomly select a first and last name from the arrays
  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  // Randomly select each character in the student's ID
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  // Add the desired number of new random grades
  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}

/**
 * @brief The structure to hold a student and their information
 * 
 * @param first_name The student's first name
 * @param last_name The student's last name
 * @param id The student's school id
 * @param *grades An array of the student's grades
 * @param num_grades The number of grades the student has in the course.  Equivalent to the length of *grades.
 */
typedef struct _student 
{ 
  char first_name[50];
  char last_name[50];
  char id[11];
  double *grades; 
  int num_grades; 
} Student;